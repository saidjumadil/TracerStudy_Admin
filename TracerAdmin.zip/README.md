# Tracer Study Admin

ini merupakan projek dari Tracer Study yang mengelola sistem bagian Admin

## How To Run

```
  $ yarn install
  $ yarn run dev
```

## Config Prettier in Vscode

```
 $ yarn run lint
 $ yarn run format
```

## Source

- [Adonis 5](https://adonisjs.com/)
- [Yarn](https://yarnpkg.com/)
